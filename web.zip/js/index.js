// 봇의 채팅을 입력함
function botchat(idx, text, ) {

}

// 하위 메뉴 보이기 또는 숨기기.
$(".rollUpNav").click(function() {
  $(".sublistContainer").slideToggle();
})

$(".showList").click(function() {
  $(".sublistContainer").slideToggle();
})

// 불만 폼 접수하기
function unsetis(idx) {
  console.log("비만족 답변 : " + idx);
  $("#setisForm").fadeIn();
}

function setis(idx) {
  console.log("만족 답변 : " + idx);
  $(this).addClass("yes");
}

$(".selectitems").click(function() {
  var text = this.innerHTML;
  var query = "<div class=\"userChatBox\"><div class=\"chat\">" + text + "<\/div><\/div>";
  $("#chatBody .container").append(query);
  sendQuery(text);
  $('#chatBody .container').scrollTop($('#chatBody .container').prop('scrollHeight'));
  $(".sublistContainer").slideUp();
})

function reset() {
  var text = "처음부터";
  var query = "<div class=\"userChatBox\"><div class=\"chat\">" + text + "<\/div><\/div>";
  $("#chatBody .container").append(query);
  sendQuery(text);
  $('#chatBody .container').scrollTop($('#chatBody .container').prop('scrollHeight'));
  $(".sublistContainer").slideUp();
}

function sendMessage() {
  if ($(".chatContent").val() == "") {
    alert("내용을 입력해주세요!");
    return false;
  } else {

    var query = "<div class=\"userChatBox\"><div class=\"chat\">" + $(".chatContent").val() + "<\/div><\/div>";

    $("#chatBody .container").append(query);

    sendQuery($(".chatContent").val());

    $(".chatContent").val("");

    $('#chatBody .container').scrollTop($('#chatBody .container').prop('scrollHeight'));

    $(".sublistContainer").slideUp();
    return false;
  }
  return false;
}

function setisform() {
  if ($(".setisText").val() == "") {
    alert("내용을 입력해 주세요!");
    return false;
  } else {
    console.log($(".setisText").val());
    $("#setisForm").fadeOut();
    return false;
  }
}

$("#setisform .background").click(function() {
  $("#setisForm").fadeOut();
})

// 쿼리를 보내는 함수
function sendQuery(text) {
  console.log(text);

  $.ajax({
    url: "https://seoakey.run.goorm.io/callNLP",
    type: "POST",
    cache: false,
    dataType: "application/json; charset=utf-8; Access-Control-Allow-Origin: *;",
    data: '{"company":"seoulcity", "system":"seoakey", "classgubun" : "ALL", "var1" : \"' + text + '\"}',
    success: function(data) {
      console.log(data)
    },
    error: function(request, status, error) {
      console.log(request+ " / " + status +" / " + error);
    }

  });

}
